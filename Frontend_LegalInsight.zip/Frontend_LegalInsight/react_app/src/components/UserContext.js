// UserContext.js
import React, { createContext, useContext, useState } from 'react';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [userdata, setUserdata] = useState(null);

  const login = (userdata) => {
    setUserdata(userdata);
  };

  const logout = () => {
    setUserdata(null);
  };

  return (
    <UserContext.Provider value={{ userdata, login, logout }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  return useContext(UserContext);
};
