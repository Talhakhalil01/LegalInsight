import React, { useState,useEffect } from 'react';
import '../styles/navbar.css';
import '../styles/central.css';
import Profile from './Profile'; // Import your Profile component
import { useNavigate } from "react-router-dom";
import { useBookmarks } from './BookmarksContext';
import axios from 'axios';
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const NavBar =() => {
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();
  const[userData,setuserData]=useState('');
  const { userdata } = useUser();
  //const[bookmarkedCases, updateBookmarkedCases]=useBookmarks();
  const {updateBookmarkedCases}=useBookmarks();
  
  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const closePopup = () => {
    setShowPopup(false);
  };
  const handleSignup = () => {
    navigate('/lawyerSignup')
  };
  const handleFind = () => {
    
  };

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);
            
        } else {
          setuserData(null);

        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);

    const handlebookmark = async () => {
      if (userData) {
          const userName=userData.username;
          try {
            // Send a POST request to the server to save the bookmark
            const response = await fetch('http://localhost:5000/fetchcases', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({userName}),
            });
  
          
          if (!response.ok) {
              //  alert("No recors exists for the login account")
              toast.info("No record exists for this account")
          }
          else
          {
            const searchData = await response.json(); // Use await response.json() to parse the JSON response
            updateBookmarkedCases(searchData);
            navigate('/bookmark');
            // console.log("Bookmarked cases in navbar are:",searchData);
          }
        } catch (error) {
          console.error('Error fetching bookmarked cases:', error);
          updateBookmarkedCases(null);

        }
        
      } else {
        // alert("Please login first")
        toast.error("Please login first")
        navigate('/signin');
      }
    };
  return (
    <div className='nav-bar'>
      <div className='mylogo'></div>
      <button className="bookmark-button" onClick={handlebookmark}>Bookmarked Cases</button>
      <button className="login-button" onClick={togglePopup}></button>
      <button className="login" onClick={handleSignup}>Create Lawyer Profile</button>
      <button className="find" onClick={handleFind}>Find lawyer</button>

      {showPopup && (
        <div className="popup-overlay" onClick={closePopup}>
          <div className="popup" onClick={(e) => e.stopPropagation()}>
            <Profile />
          </div>
        </div>
      )}
    </div>
  );
};

export default NavBar;
