import React, { createContext, useContext, useReducer } from 'react';

// Step 1: Create Context
const FormContext = createContext();

// Step 2: Define State and Actions
const initialState = {
  form1: {
    areas: "",
    experience: "",
    barAffiliation: "",
    barAffiliationimage: null,
    barAffiliationimage2: null,
    education: "",
    cecrtifications: ""
  },
  form2: {
    name: "",
    email: "",
    phone: "+92",
    province: "",
    city: "",
    currentStatus: ""
  },
  form3: {
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    certificateImage: null,
    approvalImage: null
  },
  form4: {
    education: "",
    graduationYear: "",
    date: "",
    institutes: "",
    LLBdegree: null,
    LAWGATresult: null
  },
  form5: {
    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    feesConsultation: "",
    successStories: ""
  },
  form6: {
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "", endTime: "" },
      Sunday: { startTime: "", endTime: "" }
    },
    consultationModes: [],
    consultationFees: {},
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: ""
  }
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'UPDATE_FORM_1':
      return { ...state, form1: { ...state.form1, ...action.payload } };
    case 'UPDATE_FORM_2':
      return { ...state, form2: { ...state.form2, ...action.payload } };
    case 'UPDATE_FORM_3':
      return { ...state, form3: { ...state.form3, ...action.payload } };
    case 'UPDATE_FORM_4':
      return { ...state, form4: { ...state.form4, ...action.payload } };
    case 'UPDATE_FORM_5':
      return { ...state, form5: { ...state.form5, ...action.payload } };
    case 'UPDATE_FORM_6':
      return { ...state, form6: { ...state.form6, ...action.payload } };
    default:
      return state;
  }
};

// Step 3: Wrap Forms with Context Provider
export const FormProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <FormContext.Provider value={{ state, dispatch }}>
      {children}
    </FormContext.Provider>
  );
};

// Step 4: Use Context in Forms
export const useFormContext = () => useContext(FormContext);

// Step 5: Send Data to Server
// At the end of the last form, retrieve data from the context and send it to the server
