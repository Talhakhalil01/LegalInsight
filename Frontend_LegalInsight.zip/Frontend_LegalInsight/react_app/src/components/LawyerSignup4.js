import React, { useState, useEffect } from "react";
import "../styles/LawyerSignup4.css";
import "../styles/central.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import TimePicker from "react-time-picker";
import "react-time-picker/dist/TimePicker.css";
import defaultImageIcon from "../styles/images/document4.png";
import ClipLoader from "react-spinners/ClipLoader";


const Register = () => {
  const navigate = useNavigate();
  const [image, setImage] = useState();
  const [loading, setLoading] = useState(false); // Initialize loading state as false

  const [formData, setFormData] = useState({
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts:"",
    highCourt:"",
    highCourt:"",
    certificateImage: null,
    approvalImage: null,
  });
  const highCourts = [
    { name: "Lahore High Court", principalSeat: "Lahore", benches: ["Bahawalpur", "Multan", "Rawalpindi"] },
    { name: "Sindh High Court", principalSeat: "Karachi", benches: ["Sukkur", "Hyderabad", "Larkana", "Mirpurkhas"] },
    { name: "Peshawar High Court", principalSeat: "Peshawar", benches: ["Abbottabad", "Mingora", "Dera Ismail Khan", "Bannu"] },
    { name: "Balochistan High Court", principalSeat: "Quetta", benches: ["Sibi", "Turbat"] },
    { name: "Islamabad High Court", principalSeat: "Islamabad", benches: [] },
    { name: "Azad Kashmir High Court", principalSeat: "Muzaffarabad", benches: ["Kotli", "Mirpur", "Rawalakot"] },
    { name: "Gilgit-Baltistan Chief Court", principalSeat: "Gilgit", benches: ["Skardu"] },
  ];

  // Function to handle image selection
  const  handleFrontImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, certificateImage: URL.createObjectURL(imageFile) });
  };
  // Function to handle image selection
  const  handleBackImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, approvalImage: URL.createObjectURL(imageFile) });
  };

  const handlenextpage = () => {
    setLoading(true); // Set loading state to true when transitioning to the next page
    setTimeout(() => {
      navigate("/lawyerSignup5"); // Navigate to the next page after a delay (simulating loading)
    }, 300); // Adjust the delay as needed
  };

  const handlePositionChange = (selectedOption) => {
    setFormData({ ...formData, currentPosition: selectedOption.value });
  };

  return (
    <div className="signup-wrapper8">
      <div className="wrapper8">
        <form action="">
          <h1>Lawyer Signup</h1>

          <div className="input-box8">
            <label className="label">Select your current position:</label>
            
             <select
                    name="current-position"
                    className="current-position"
                    value={formData.currentPosition}
                    onChange={(e) => setFormData({ ...formData, currentPosition: e.target.value })}
                  >
                      <option value="">Select Current  Position</option>
                      <option value="Enrolled Lawyer/Advocate">Enrolled Lawyer/Advocate</option>
                      <option value="Advocate High Court">Advocate High Court</option>
                      <option value="Advocate Supreme Court">Advocate Supreme Court</option>
                      <option value="Senior Advocate Supreme Court">Senior Advocate Supreme Court</option>
                     
                   
                    
              </select>
          </div>

          {formData.currentPosition && (
            <div>
              <div className="input-box8">
              <label className="label">Duration of Practice as {formData.currentPosition}:</label>
              <input
                type="text"
                className="duration-of-practice"
                value={formData.durationOfPractice}
                onChange={(e) => setFormData({ ...formData, durationOfPractice: e.target.value })}
              />
            </div>
            <div className="input-box8">
                <label className="label">Enter your practicing lower court names:</label>
                <input 
                type="text" 
                value={formData.lowerCourts} 
                placeholder="Lower court name 1,Lower court name2,...etc."
                onChange={(e) => setFormData({ ...formData, lowerCourts: e.target.value })}
                required
                />
            </div>

            </div>
            
            
          )}
    {formData.currentPosition === "Enrolled Lawyer/Advocate" && (
            <div>
                
              
            <div className="input-box8" id="img1">
                <label id="label-image1">Upload Certificate of completion of six months apprenticeship</label>
                <input
                type="file"
                id="image-input"
                onChange={handleFrontImageChange}
                />
            
             {formData.certificateImage ? (
                <img className="image" src={formData.certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>

            <div className="input-box8" id="img2">
                <label id="label-image2">Upload Certificate issued by the Bar Council:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.approvalImage ? (
                    <img className="image2" src={formData.approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            </div>
          )}
          {formData.currentPosition === "Advocate High Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Select your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
            </div>

           
              
            <div className="input-box8" id="img1">
                <label id="label-image1">Upload two years Confirmation of practice in the lower Courts:</label>
                <input
                type="file"
                id="image-input"
                onChange={handleFrontImageChange}
                />
            
             {formData.certificateImage ? (
                <img className="image" src={formData.certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>

            <div className="input-box8" id="img2">
                <label id="label-image2">Upload Application Acknowledgment from High Court Judges:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.approvalImage ? (
                    <img className="image2" src={formData.approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            </div>
          )}

          {formData.currentPosition === "Advocate Supreme Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Select your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
            </div>

            <div className="input-box8" id="img1">
                <label id="label-image1">Upload seven years Confirmation of practice at the High Courts:</label>
                <input
                type="file"
                id="image-input"
                onChange={handleFrontImageChange}
                />
            
             {formData.certificateImage ? (
                <img className="image" src={formData.certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>
            <div className="input-box8" id="img2">
                <label id="label-image2">Upload Approval Notification from Supreme Court Judges' Panel:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.approvalImage ? (
                    <img className="image2" src={formData.approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>
            

          </div>
             
          )}
          {formData.currentPosition === "Senior Advocate Supreme Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Select your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
               </div>
                <div className="input-box8" id="img1">
                <label id="label-image1">Upload fifteen years Confirmation of practice in the Supreme Court:</label>
                <input
                type="file"
                id="image-input"
                onChange={handleFrontImageChange}
                />
            
             {formData.certificateImage ? (
                <img className="image" src={formData.certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>
            <div className="input-box8" id="img2">
                <label id="label-image2">Upload Approval Notification from Supreme Court Judges' Panel:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.approvalImage ? (
                    <img className="image2" src={formData.approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>
                
           
            
            </div>

             
          )}

          {loading ? (
            <div className="loading-spinner">
              <ClipLoader color={"#007bff"} loading={loading} size={100} />
            </div>
          ) : (
            <button type="button" onClick={handlenextpage}>
              Next
            </button>
          )}
          <div className="register-link8">
            <p>Form 4 of 7</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register