// Judgement.js
import React from 'react';
import '../styles/judgement.css';


const Judgement = ({ judgement, onClose }) => {
  return (
    <div className="judgement-popup">
      <div className="judgement-content">
        <span className="close" onClick={onClose}>&times;</span>
        <h2>Full Text of the Judgment</h2>
        <p>{judgement}</p>
      </div>
    </div>
  );
};

export default Judgement;
