import React, { useState } from 'react';
import '../styles/advancesearchbar.css';
import '../styles/central.css';

const AdvanceSearchBar= ({ onSearchResults }) => {
  const [showOptions, setShowOptions] = useState(false);

  const toggleAdvanceOptions = () => {
    setShowOptions(!showOptions);
  };
  const [searchData, setSearchData] = useState({
    caseno: '',
    casesubject: '',
    casetitle: '',
    judgename: '',
    judgementdate: '',
    courtname: '',
    casecitation: '',
    keyword: '',
  });
  const handleSearch = async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    // Collect form data
    const formData = new FormData(e.target);
    const searchData = {};
    formData.forEach((value, key) => {
      searchData[key] = value;
    });

    // Send the form data to the server
    try {
      const response = await fetch('http://localhost:5000/search2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchData),
      });
      if (!response.ok) {
        throw new Error('Failed to send form data to the server');
      }
      else
      {
          const searchData = await response.json();
          console.log("Data received at advancesearchbar.js:", searchData);


          onSearchResults(searchData);
      }

     
    } catch (error) {
      // Handle network or other errors
      console.error('Error during search:', error);
      onSearchResults(null);
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const handleClearData = () => {
    // Clear all the fields
    setSearchData({
      caseno: '',
      casesubject: '',
      casetitle: '',
      judgename: '',
      judgementdate: '',
      courtname: '',
      casecitation: '',
      keyword: '',
    });
  };
  return (
    <div className="advance-search-bar">
      <button type="button" className={`button4 ${showOptions ? 'showOptions' : ''}`} onClick={toggleAdvanceOptions}>
        {showOptions ? 'Hide Advance Search Options' : 'Show Advance Search Options'}
      </button>

      {showOptions && (
        <form onSubmit={handleSearch}>
          {/* Your existing input fields and buttons go here */}
          <input
          type="text"
          placeholder="Search with case no."
          className="caseno"
          name="caseno"
          value={searchData.caseno}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with case subject"
          className="casesubject"
          name="casesubject"
          value={searchData.casesubject}
          onChange={handleChange}
        />
         <input
          type="text"
          placeholder="Search with case title"
          className="casetitle"
          name="casetitle"
          value={searchData.casetitle}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with judge name"
          className="judgename"
          name="judgename"
          value={searchData.judgename}
          onChange={handleChange}
        />
       <input
          type="text"
          placeholder="Search with judgement date"
          className="judgementdate"
          name="judgementdate"
          value={searchData.judgementdate}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with court name"
          className="courtname"
          name="courtname"
          value={searchData.courtname}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with case citation"
          className="casecitation"
          name="casecitation"
          value={searchData.casecitation}
          onChange={handleChange}
        />
        
        
        <input
          type="text"
          placeholder="Search with specific keyword"
          className="keyword"
          name="keyword"
          value={searchData.keyword}
          onChange={handleChange}
        />
        <button type="button" className='button5' onClick={handleClearData}>ClearData</button>
       <button type="submit" className='button3'>Search</button>
        </form>
      )}
    </div>
  );
};

export default AdvanceSearchBar;

