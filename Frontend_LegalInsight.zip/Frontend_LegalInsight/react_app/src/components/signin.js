import React, { useState,useEffect } from "react"
import "../styles/signin.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import '../styles/central.css';
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';




const Signin = () => 
{
    

  const navigate = useNavigate();
  const { userdata, login, logout } = useUser();
  const[userData,setUserData]=useState('');
  const [formData, setFormData] = useState({
    
    username: '',
    password: '',
  });
 
  const [formData2, setFormData2] = useState({
    username: '',
    password: '',
  });

 
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            
            // If the user is logged in, set the form data with the user's email
            login(response.data.userData);
            setUserData(response.data.userData);
           

        } else {
          setUserData(null);
          //alert('User not logged-In')
          

          
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData2((prevData) => ({ ...prevData, [name]: value }));
  };

  // const handleEmailClick = () => {
  //   if (userData) {
  //     setFormData2((prevData) => ({ ...prevData, username: userData.username }));
  //   }
  // };

  // const handlePasswordClick = () => {
  //   if (userData) {
  //     setFormData2((prevData) => ({ ...prevData, password: userData.password || "" }));
  //   }
  // };

  const [showPassword2, setShowPassword2] = useState(false);

 
  const handleSignup=()=>{
    navigate('/signup');
  }
  
  const handleSubmit2 = async (event) => {
    event.preventDefault();

    const data = {
      username: formData2.username,
      password: formData2.password,
    };

    try {
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include'
      });

      if (response.ok) {
        
        setFormData2({
          username: "",
          password: ""
        });

        // Get the user data from the response
       const userdata = await response.json();


       // Call the login function from UserContext to update userData
        login(userdata);
        navigate('/');

      } else {
        console.error('Login failed');
        //alert('Incorrect username or password');
        toast.error("Incorrect username or password")
      }
    } catch (error) {
      console.error('Error during login:', error.message);
    }
  };
 
  
    return (
        <div className="signup-wrapper">
        <div className="wrapper">
          <form action="" onSubmit={handleSubmit2}>
            <h1>Sign In</h1>
  
            <div className="input-box">
              <input 
              // type="email"
              // placeholder="Email"
              // required
              // name="email"
              // value={formData2.email}
              // onChange={(e) => setFormData2({ ...formData2, email: e.target.value })}
              type="text"
              placeholder="Username"
              required
              name="username"
              value={formData2.username}
              onChange={handleInputChange}
              />
              <FaUser className="icon"/>
            </div>
  
            <div className="input-box">
              <input 
              // type="password" 
              // placeholder="Password" 
              // required
              // name="password"
              // value={formData2.password}
              // onChange={(e) => setFormData2({ ...formData2, password: e.target.value })}
              // onClick={handlePasswordClick} // Add onClick handler for password field

              type="password"
              placeholder="Password"
              required
              name="password"
              value={formData2.password}
              onChange={handleInputChange}
              
              />
              <FaLock className="icon"/>
            </div>

            {/* <div className="remember">
            <label>
              <input
                type="checkbox"
                name="rememberMe"
                checked={formData2.rememberMe}
                onChange={(e) =>setFormData2({...formData2,rememberMe: e.target.checked,})}
              />
              Remember me
            </label>
          </div> */}
  
            <button type="submit">Login</button>
            <div className="register-link">
              <p>Don't have an account?<a href="#" onClick={handleSignup}>Sign Up</a></p>
            </div>
          </form>
        </div>
       </div> 
    )
  

};
export default Signin;