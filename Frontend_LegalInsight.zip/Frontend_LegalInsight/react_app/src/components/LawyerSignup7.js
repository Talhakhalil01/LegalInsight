import React, { useState,useEffect } from "react"
import "../styles/LawyerSignup7.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import TimePicker from 'react-time-picker';
import Select from 'react-select';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import { MdExpandLess } from "react-icons/md";
import { MdExpandMore } from "react-icons/md";
import defaultImageIcon from '../styles/images/img.png';
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'
import { GrValidate } from "react-icons/gr";
import { RxCross1 } from "react-icons/rx";






const Register = () => {
  
  const navigate = useNavigate();
  const [image, setImage] = useState();

  const [formData, setFormData] = useState({
      lawyerImage:null,
      facebook:"",
      whatsapp:"+92",
      twitter:"",
      linkedin:""

  });
 
  const  handleFrontImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, lawyerImage: URL.createObjectURL(imageFile) });

   
};
  

    return (
    <div className="signup-wrapper7">
      <div className="wrapper7">
        <form action="">
          <h1>Lawyer Signup</h1>
         
          <div className="input-box7" id="img1">
                <label id="label-image1">Upload a your formal image:</label>
                <input
                type="file"
                id="image-input"
                // accept="image/*"
                onChange={handleFrontImageChange}
                />
                
             {/* Image viewer for front image */}
             {formData.lawyerImage ? (
                <img className="image" src={formData.lawyerImage} alt="Lawyer Image" />
                ):(
                    <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
                )}
            </div>

            <div className="input-box7" id="input3">
            <label>Enter your WhatsApp number:</label>
            <input
                type="tel"
                name="whatsapp"
                value={formData.whatsappp}
                onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                placeholder="WhatsApp Number"
            />
            {formData.whatsapp && formData.whatsapp.length > 3 && (
                  <div className="extra">
                      {isValidPhoneNumber(formData.whatsapp) ? (
                          <>
                              <GrValidate className="tick" /> 
                              <span className="valid-message">Valid Phone number</span>
                          </>
                      ) : (
                          <>
                              <RxCross1 className="cross" />
                              <span className="invalid-message">Invalid Phone number</span>
                          </>
                      )}
                  </div>
              )}
            </div>

            <div className="input-box7" id="input2">
            <label>Enter your Facebook Profile Link(if any):</label>
            <input
                type="url"
                name="facebook"
                value={formData.facebook}
                onChange={(e) => setFormData({ ...formData, facebook: e.target.value })}
                placeholder="Facebook profile link"
            />
            </div>
           
            {/* <div className="input-box7" id="input4">
            <label>Enter your Twitter Profile Link(if any):</label>
            <input
                type="url"
                name="twitter"
                value={formData.twitter}
                onChange={(e) => setFormData({ ...formData, twitter: e.target.value })}
                placeholder="Twitter profile link"
            />
            </div> */}
            <div className="input-box7" id="input5">
            <label>Enter your LinkedIn Profile Link(if any):</label>
            <input
                type="url"
                name="linkedin"
                value={formData.linkedin}
                onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })}
                placeholder="LinkedIn profile link"
            />
            </div>
            



         
            
             


          <button type="button">Next</button>
          <div className="register-link7">
            <p>Form 7 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;