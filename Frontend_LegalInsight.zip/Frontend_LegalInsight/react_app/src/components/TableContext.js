import React, { createContext, useContext, useState } from 'react';

const TableContext = createContext();

export const TableProvider = ({ children }) => {
  const [tableData, setTableData] = useState(null);
  const [queryData, setQueryData] = useState(null);
  const [search, setSearch] = useState("");

  const updateTableData = (newData) => {
    setTableData(newData);
  };
  const updateQueryData = (newData2) => {
    setQueryData(newData2);
  };
  const updateSearch = (newData3) => {
    setSearch(newData3);
  };
  

  return (
    <TableContext.Provider value={{ tableData,queryData,search, updateTableData,updateQueryData,updateSearch }}>
      {children}
    </TableContext.Provider>
  );
};

export const useTable = () => {
  const context = useContext(TableContext);
  if (!context) {
    throw new Error('useTable must be used within a TableProvider');
  }
  return context;
};
