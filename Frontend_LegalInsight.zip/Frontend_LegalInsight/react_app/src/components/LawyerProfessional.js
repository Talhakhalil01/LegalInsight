import React, { useState,useEffect } from "react"
import "../styles/LawyerProfessional.css"
import '../styles/central.css';
import defaultImageIcon from '../styles/images/document4.png';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { IoMdCall } from "react-icons/io";
import { HiBuildingOffice2 } from "react-icons/hi2";
import { ImCross } from "react-icons/im";
import { GrValidate } from "react-icons/gr";
import 'react-phone-number-input/style.css'
import Select from 'react-select';
import { PropagateLoader } from 'react-spinners';
import { BallTriangle } from 'react-loader-spinner';
import ClipLoader from "react-spinners/ClipLoader";
import { useFormContext } from "./FormContext"; // Import the useFormContext hook

// import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'





const Register = () => {
  
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
  const [image, setImage] = useState();

  const [formData, setFormData] = useState({
    areas: "",
    experience: "",
    barAffiliation:"",
    barAffiliationimage:null,
    barAffiliationimage2:null,
    education: "",
    cecrtifications:""    
  });
  
  
const practiceAreas = [
    "Administrative Law", "Admiralty & Aviation Law", "Agribusiness", "Alternative Dispute Resolution", "Appellate Practice", "Arbitration Law", "Asset Management Company", "Asset Search & Background Investigation", "Attestation & Legalization Services", 
    "Banking & Finance", "Blue Collar Crime", "Brokerage Company", "Business Law", "Business Tax Planning", "Capital Markets", "Child Abduction Law", "Child Adoption", "Child Custody Law", "Citizenship & Residency", 
    "Civil Law & Civil Rights", "Commercial Law", "Company Law", "Company Secretarial Services", "Competition Law", "Constitutional Law", "Construction Company", "Consumer Protection Law", "Contract Law & Enforcement", "Copyright Law", 
    "Corporate Governance", "Corporate Law", "Criminal Law", "Customs Law", "Cyber Crime Law", "Debt Collection & Recovery", "Defamation Law", "Design Registration Services", "Divorce Law", "Drafting & Vetting", 
    "Due Diligence Services", "E-Commerce Law", "E-Contract Services", "E-Governance Law", "E-Waste Law", "Employment Law", "Energy Law", "Energy Projects", "Enforcement of Foreign Judgment", "Environmental Law", 
    "Escrow Services", "Estate Planning Law", "Expert Witnesses", "Family Law", "Federal Excise Law", "Foreign Exchange Company", "Franchising Law", "Human Resource Manual", "Human Rights Law", "Immigration & Citizenship", 
    "Import & Export Registration", "Income Tax Law", "Inheritance & Succession Law", "Insolvency Law", "Insurance Company", "Insurance Law", "Intellectual Property Enforcement", "Intellectual Property Law", "International Business Transactions", 
    "International Law", "International Tax Law", "Investment Law", "IT Services Company", "Joint Ventures", "Labour Law", "Land Acquisition Law", "Leasing Law", "Legal Translation Services", "Limited Liability Partnership", 
    "Liquefied Natural Gas Company", "Litigation", "Mediation Law", "Mergers & Acquisitions", "Mirror Judgment / Order", "Modaraba Company", "Mortgage Law", "Non Banking Finance Company", "Non Governmental Organization", "Offshore Company", 
    "Oil & Gas Law", "Patent Law", "Payroll Services", "Personal Injury", "Pharmaceutical Company", "Process Service", "Provident Fund", "Provisional Refusal Services", "Real Estate Law", "Recruitment Company", 
    "Sales Tax Law", "Sales Tax Refund", "Sales Tax Returns", "Satellite Launch Contracts", "Security Services Company", "Telecommunication Company", "Textile Company", "Trademark Law", "Travel Agency", "University Setup", "White Collar Crime"
  ];
  
  // Function to handle image selection
  const  handleFrontImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, barAffiliationimage: URL.createObjectURL(imageFile) });
    console.log("Bar card image 1:",formData.barAffiliationimage)

   
  };
  // Function to handle image selection
  const  handleBackImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, barAffiliationimage2: URL.createObjectURL(imageFile) });
    console.log("Bar card image 2:",formData.barAffiliationimage)
  };

  const handlenextpage = () => {
    setLoading(true); 
    setTimeout(() => {
       navigate('/lawyerSignup2')
    }, 500);   
    
  }
  // useEffect(()=>{
  //   setLoading(true); 
  //   setTimeout(() => {
  //      setLoading(false);
  //   }, 500); 
  // });

    return (
    <div className="signup-wrapper3">
      <div className="wrapper3">
        <form action="">
          <h1>Lawyer Signup</h1>
          <div className="input-box3" id="practicearea">
            <label className="label">Select your legal practice area:</label>
            
          </div>
          <Select
                    className="reactselect"
                    value={formData.areas}
                    onChange={(areas) => setFormData({ ...formData, areas })}
                    options={practiceAreas.map(area => ({ label: area, value: area }))}
                    isSearchable
                    isMulti
                    placeholder="Search or select legal practice area..."
            />
          
          

          {/* <div className="input-box3">
            <label className="label">Enter your years of experience:</label>
            <input 
                    type="number" 
                    className="input-experience" 
                    id="Experience" 
                    name="yearsOfExperience" 
                    placeholder="Enter years of experience"
                    value={formData.experience}
                    min="0"  // Set minimum value to 0
                    max="100" // Set maximum value to 100 (you can adjust this as needed)
                    step="1"  // Set step increment to 1
                    onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                />
          </div> */}
         

        
          

          <div className="input-box3" id="Barassocation">
              <label className="label">Select your Affiliated Bar Council:</label>
              <select 
                    id="barcouncil" 
                    value={formData.barAffiliation} 
                    onChange={(e) => setFormData({ ...formData, barAffiliation: e.target.value })}
               >
                    <option value="">Select Bar Council</option>
                    {/* <option value="Pakistan Bar Council">Pakistan Bar Council</option> */}
                    <option value="Punjab Bar Council">Punjab Bar Council</option>
                    <option value="Sindh Bar Council">Sindh Bar Council</option>
                    <option value="Khyber Pakhtunkhwa Bar Council">Khyber Pakhtunkhwa Bar Council</option>
                    <option value="Balochistan Bar Council">Balochistan Bar Council</option>
                    <option value="Islamabad Bar Council">Islamabad Bar Council</option>
                    <option value="Azad Jammu & Kashmir Bar Council">Azad Jammu & Kashmir Bar Council</option>
                    <option value="Gilgit Baltistan Bar Council">Gilgit Baltistan Bar Council</option>
            </select>
          </div>
          <div className="input-box3">
              <label className="label">Enter your Affiliated Bar Association:</label>
              <input 
                    type="text" 
                    className="bar-association" 
                    name="barAssociation" 
                    placeholder="E.g:Rawalpindi bar association,etc."
                    value={formData.barAssociation}
                    onChange={(e) => setFormData({ ...formData, barAssociation: e.target.value })}
                />
          </div>

          {/* Front image input for bar affiliation verification */}
            <div className="input-box3" id="img1">
                <label id="label-image1">Upload front image of your bar card:</label>
                <input
                type="file"
                id="image-input"
                // accept="image/*"
                onChange={handleFrontImageChange}
                />
                
             {/* Image viewer for front image */}
             {formData.barAffiliationimage ? (
                <img className="image" src={formData.barAffiliationimage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>
            

           
            <div className="input-box3" id="img2">
                <label id="label-image2">Upload back image of your bar card:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.barAffiliationimage2 ? (
                    <img className="image2" src={formData.barAffiliationimage2} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>
             
            <div className="input-box3" id="note-label">
            <label className="label" id="label-note">(Note: Only the practicing lawyers are allowed to create their profile.) </label>
           
          </div>
             
          {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="button" onClick={handlenextpage}>Next</button>
          )}

          {/* <button  type="button" onClick={handlenextpage}>Next</button> */}
          <div className="register-link3">
            <p>Form 1 of 7</p>
          </div>
        </form>
      </div>
    </div> 

)
    
  

        
};
export default Register;