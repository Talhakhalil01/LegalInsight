import React, { useState } from 'react';
import SearchBar from './SearchBar';
import AdvanceSearchBar from './AdvanceSearchBar';
import NavBar from './NavBar'; 
import Table from './Table';
import { useTable } from './TableContext';
import '../styles/Home.css';
import '../styles/Searchbar.css';
import '../styles/advancesearchbar.css';
import '../styles/Table.css';
import '../styles/central.css';
import { Outlet } from 'react-router-dom';

 const Home=({ bookmarkedcases })=>{


  // const { tableData, updateTableData } = useTable()

  // const handleSearchComplete = (data) => {
  //   updateTableData(data);
  // };
  //  const handleSearchComplete2 = (data) => {
  //   bookmarkedcases(data);
  // };
  


  return (
    <div className="home-container">
      <div className="navbar"><NavBar/></div>
      <div className="searchbar"><SearchBar/></div>
      {/* <div className="advancesearchbar"><AdvanceSearchBar onSearchResults={handleSearchComplete}/></div> */}
      <div className="Table"><Table/></div>
    </div>
  );
}
export default Home;

