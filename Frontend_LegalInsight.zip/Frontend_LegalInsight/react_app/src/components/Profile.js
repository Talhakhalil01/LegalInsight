import React, { useState,useEffect } from "react"
import '../styles/Profile.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Profile=()=> {

  const[userData,setuserData]=useState('');
  const { userdata, login, logout } = useUser();
  const navigate = useNavigate()
 
  

  const handleLogout = async() => {
            //  navigate('/signin');
    if (!userdata) {
      toast.error('User not logged in');
      //navigate('/signin');
      console.log("User data is::",userdata)
    }
  else{
      try {
        const response = await axios.post('http://localhost:5000/logout');
        if (response.data.success) {
          
          toast.success("Logged out successfully")
          logout(); // Update user data context on successful logout
          setuserData(null);
          
        
          
        } else {
          console.error('Logout failed:', response.data.message);
          alert('Logged out failed');
        }
      } catch (error) {
        console.error('Error during logout:', error.message);
        
      }
  }

    // useEffect to navigate after the state update
    
  };
  
  const signInToAnotherAccount=()=> {
       navigate('/signin')
  }
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);
            
        } else {
          setuserData(null);
          //alert('User not logged-Innnn')
          

          
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);
 


  return (
    <div className="profile-content">
      <h2 className="heading">Account Details</h2>
      <p className='username'>
        <strong>Username:</strong> {userData ? userData.username : 'undefined'}
      </p>
      <p className='email'>
        <strong>Email:</strong> {userData ? userData.email : 'undefined'}
      </p>
      <button className="Logout" onClick={handleLogout}>Sign out</button>
      <button className="Signin" onClick={signInToAnotherAccount}>Change Account</button>
    </div>
  );
}



export default Profile;
