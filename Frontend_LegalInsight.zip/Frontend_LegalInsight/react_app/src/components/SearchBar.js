import React, { useState } from 'react';
import '../styles/Searchbar.css';
import '../styles/central.css';
import { useTable } from './TableContext';

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { tableData, updateTableData } = useTable()
  const { queryData, updateQueryData } = useTable()
  const {search, updateSearch} = useTable();

  const handleSearch = async (e) => {
    e.preventDefault();
    updateQueryData(searchQuery);
   

    try {
      const response = await fetch('http://localhost:5000/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ searchQuery }),
      });

      if (!response.ok) {
        throw new Error('Server error');
        updateTableData([]);
      }
      else
      {
          const searchData = await response.json();
          console.log("Data received at searchbar.js:", searchData.length);
          updateTableData(searchData);
          updateSearch("MainSearchbar")
          
          
      }

    } catch (error) {
      console.error('Error during search:', error.message);
      // Pass searchData as null to indicate an error
      updateTableData([]);
    }
  };

  return (
  
    <form onSubmit={handleSearch} className="search-bar">
      <input
        className='search'
        type="text"
        id="searchInput"
        placeholder="Search for reported judgments here"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        required
      />
      <button type="submit" className='searchbtn'>Search</button>
    </form>

  );
};

export default SearchBar;
