import React, { useState,useEffect } from "react"
import "../styles/LawyerSignup2.css"
import '../styles/central.css';
import defaultImageIcon from '../styles/images/document4.png';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import Select from 'react-select';
import ClipLoader from "react-spinners/ClipLoader";


const Register = () => {
  
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
 

  const [formData, setFormData] = useState({
    education: "",
    graduationYear: "",
    date:"",
    institutes: "",
    LLBdegree:null,
    LAWGATresult:null
  });
  const years = [];
    for (let year = 1980; year <= new Date().getFullYear(); year++) {
    years.push(year.toString());
    }
  
const handlenextpage = () => {
        setLoading(true); // Set loading state to true when transitioning to the next page
        setTimeout(() => {
          navigate('/lawyerSignup4'); // Navigate to the next page after a delay (simulating loading)
        }, 500); // Adjust the delay as needed
      }
// Function to handle image selection
const  handleFrontImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, LLBdegree: URL.createObjectURL(imageFile) });
    console.log("Bar card image 1:",formData.LLBdegree)

   
};
  // Function to handle image selection
  const  handleBackImageChange = (e) => {
    const imageFile = e.target.files[0];
    setFormData({ ...formData, LAWGATresult: URL.createObjectURL(imageFile) });
    console.log("Bar card image 2:",formData.LAWGATresult)
  };
    return (
    <div className="signup-wrapper4">
      <div className="wrapper4">
        <form action="">
          <h1>Lawyer Signup</h1>
          
          <div className="input-box4">
            <label className="label">What's your education:</label>
            <select
                id="education"
                name="education"
                value={formData.education}
                onChange={(e) => setFormData({ ...formData, education: e.target.value })}
            >
                <option value="">Select Law Degree</option>
                <option value="LLB">Bachelor of Laws (LLB)</option>
                <option value="LLM">Master of Laws (LLM)</option>
                <option value="LLD">Doctor of Laws (LLD)</option>
          </select>

          </div>
          <div className="input-box4">
            <label className="label">Select your LLB graduation year:</label>
            <select
                id="date"
                name="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            >
                <option value="">Select graduation year</option>
                {years.map((year) => (
                <option key={year} value={year}>
                    {year}
                </option>
                ))}
             </select>


          </div>
          <div className="input-box4">
            <label className="label">Enter your corresponding institutions name:</label>
            <input 
                type="text" 
                id="institutes"
                placeholder="LLB degree institute, LLM degree institute(if any), LLD degree institute(if any)" 
                required
                name="institutes"
                value={formData.institutes}
                onChange={(e) => setFormData({ ...formData, institutes: e.target.value })}
            />
             

          </div>
          <div className="input-box4" id="img1">
                <label id="label-image1">Upload a clear image of your LLB degree:</label>
                <input
                type="file"
                id="image-input"
                // accept="image/*"
                onChange={handleFrontImageChange}
                />
                
             {/* Image viewer for front image */}
             {formData.LLBdegree ? (
                    <img className="image" src={formData.LLBdegree} alt="LLB Degree Image" />
                ) : (
                    <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
                )}
            </div>
            

           
            <div className="input-box4" id="img2">
                <label id="label-image2">Upload a clear image of your LAW-GAT result:</label>
                <input
                type="file"
                id="image-input2"
                onChange={handleBackImageChange}
                />
               {formData.LAWGATresult ? (
                    <img className="image2" src={formData.LAWGATresult} alt="LAW-GAT result Image" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="button" onClick={handlenextpage}>Next</button>
          )}

          <div className="register-link4">
            <p>Form 3 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;