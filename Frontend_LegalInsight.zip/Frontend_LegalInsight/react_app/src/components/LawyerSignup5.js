import React, { useState,useEffect } from "react"
import "../styles/LawyerSignup5.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { IoMdCall } from "react-icons/io";
import { HiBuildingOffice2 } from "react-icons/hi2";
import { ImCross } from "react-icons/im";
import { GrValidate } from "react-icons/gr";
import 'react-phone-number-input/style.css'
import Select from 'react-select';
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'
import ClipLoader from "react-spinners/ClipLoader";




const Register = () => {
  
  const navigate = useNavigate();
  const [image, setImage] = useState();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
 

  const [formData, setFormData] = useState({
   licenseNumber:"",
   certifications:"",
   caseExperience:"",
   notableCases:"",
   feesConsultation:"",
   successStories:""
  });
  
  const handlenextpage = () => {
    setLoading(true); // Set loading state to true when transitioning to the next page
    setTimeout(() => {
      navigate('/lawyerSignup6'); // Navigate to the next page after a delay (simulating loading)
    }, 300); // Adjust the delay as needed
  }


    return (
    <div className="signup-wrapper5">
      <div className="wrapper5">
        <form action="">
          <h1>Lawyer Signup</h1>
          <div className="input-box5" id="input1">
                <label id="label1">Bar License Number:</label>
                <input
                    type="text"
                    id="licenseNumber"
                    name="licenseNumber"
                    value={formData.licenseNumber}
                    onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                    placeholder="E.g:123456,etc."
                />
            </div>
            <div className="input-box5">
                <label>Specialized Certifications:</label>
                <textarea
                    id="certifications"
                    name="certifications"
                    value={formData.certifications}
                    onChange={(e) => setFormData({ ...formData, certifications: e.target.value })}
                    placeholder="E.g:Certified in Family Law,Certified in Criminal Law,etc."
                />
            </div>
            <div className="input-box5">
                <label>Case Experience:</label>
                <textarea
                    id="caseExperience"
                    name="caseExperience"
                    value={formData.caseExperience}
                    onChange={(e) => setFormData({ ...formData, caseExperience: e.target.value })}
                    placeholder="E.g:Handled various divorce cases with successful outcomes,etc."
                />
            </div>
            <div className="input-box5">
                <label>Notable Cases Handled:</label>
                <textarea
                    id="notableCases"
                    name="notableCases"
                    value={formData.notableCases}
                    onChange={(e) => setFormData({ ...formData, notableCases: e.target.value })}
                    placeholder="E.g:Won landmark case X vs. Y in Supreme Court.,etc."
                />
            </div>
            <div className="input-box5">
                <label>Success Stories or Outcomes:</label>
                <textarea
                    id="successStories"
                    name="successStories"
                    value={formData.successStories}
                    onChange={(e) => setFormData({ ...formData, successStories: e.target.value })}
                    placeholder="E.g:Helped client Z win custody battle.,etc."
                />
            </div>
            {/* <div className="input-box5">
                <label>Fees and Consultation:</label>
                <textarea
                    id="feesConsultation"
                    name="feesConsultation"
                    value={formData.feesConsultation}
                    onChange={(e) => setFormData({ ...formData, feesConsultation: e.target.value })}
                    placeholder="E.g:Initial consultation fee: 2000. Hourly rate: 3000,etc."
                />
            </div> */}

     {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="button" onClick={handlenextpage}>Next</button>
          )}
          <div className="register-link5">
            <p>Form 5 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;