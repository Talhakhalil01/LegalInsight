import React, { useState } from 'react';
import './styles/App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import Signup from './components/signup';
import Signin from './components/signin';
import { TableProvider } from './components/TableContext';
import Bookmarks from './components/Bookmarks';
import { UserProvider } from './components/UserContext';
import { BookmarksProvider } from './components/BookmarksContext';
import { useFormContext } from "./components/FormContext"; 
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Register from './components/LawyerPersonal';
import Register2 from './components/LawyerPersonal2';
import Professional from './components/LawyerProfessional';
import Professional2 from './components/LawyerSignup4';
import Professional3 from './components/LawyerSignup5';
import Professional4 from './components/LawyerSignup6';
import Professional5 from './components/LawyerSignup7';
// import { BookmarksProvider } from './components/BookmarksContext';


function App() {
  
  return (
    <BrowserRouter>
    <TableProvider>
      <useFormContext>
     <BookmarksProvider>
      <UserProvider>
        <Routes> {/* Change this to Route */}
              <Route path="/" element={<Home/>} />
              <Route path="/signup" element={<Signup/>} />
              <Route path="/signin" element={<Signin/>} />
              <Route path="/bookmark" element={<Bookmarks/>}/>
              <Route path="/lawyerSignup" element={<Professional/>}/>
              <Route path="/lawyerSignup2" element={<Register/>}/>
              <Route path="/lawyerSignup3" element={<Register2/>}/>
              <Route path="/lawyerSignup4" element={<Professional2/>}/>
              <Route path="/lawyerSignup5" element={<Professional3/>}/>
              <Route path="/lawyerSignup6" element={<Professional4/>}/>
              <Route path="/lawyerSignup7" element={<Professional5/>}/>
        </Routes>
        <ToastContainer
          position="top-center"
          autoClose={1000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          style={{ width: '350px' }} 
          />
      </UserProvider>
      </BookmarksProvider>
      </useFormContext>
     </TableProvider>
    </BrowserRouter>
  )
}

export default App;
